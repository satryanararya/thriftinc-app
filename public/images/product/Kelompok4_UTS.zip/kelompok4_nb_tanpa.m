% Membaca data
data = readtable("heartdisease.xlsx");
disp(data)

% Normalisasi dengan method ‘zscore’
disp('Normalisasi')
normalisasi = normalize(data, "zscore");
disp(normalisasi)

% Mencari PCA
disp('matriks data')
matriksData = table2array(normalisasi);
disp(matriksData)
disp('Y')
Y = matriksData(:,12);
disp(Y)
[coeff, score, ~,~,explained] = pca(matriksData);

% Menghitung jumlah principal component yang akan digunakan
disp('num_components')
num_components = find(cumsum(explained)/sum(explained) >= 0.70, 1);
disp(num_components)

% Memproyeksikan data ke matriks yang baru
disp('matriks pca')
matriks_pca = matriksData * coeff(:,1:num_components);
disp(matriks_pca)

% Membagi data menjadi 2 untuk training dan testing
disp('Membagi data training dan testing')
cv = cvpartition(Y,'HoldOut',0.5);
Xtrain = matriks_pca(cv.training,:);
Ytrain = Y(cv.training);
Xtest = matriks_pca(cv.test,:);
Ytest = Y(cv.test);
disp('Data X Training')
disp(Xtrain);
disp('Data Y Training')
disp(Ytrain);
disp('Data X Testing')
disp(Xtest);
disp('Data Y Testing')
disp(Ytest);

% Naive Bayes
% Train classifier on training data
disp('Klasifikasi training data')
nb = fitcnb(Xtrain,Ytrain);
disp(nb)

% Test classifier on testing data
disp('Klasifikasi testing data')
Yprednb = nb.predict(Xtest);
disp(Yprednb)

% Evaluate performance
disp('Evaluasi')
cm = confusionmat(Ytest,Yprednb);
confusionchart(cm)
ignb = confusionchart(cm,"Title","Naive Bayes");
% Akurasi
fprintf('Akurasi = ')
accuracy = sum(Yprednb == Ytest)/length(Ytest);
disp(accuracy)
% Precision
fprintf('Precision = ')
precision = cm(2,2)/(cmnb(2,2)+cm(1,2));
disp(precision)
% Recall
fprintf('Recall = ')
recall = cm(2,2)/(cm(2,2)+cm(2,1));
disp(recall)