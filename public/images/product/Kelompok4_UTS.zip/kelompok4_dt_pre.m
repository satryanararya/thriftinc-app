% Membaca data
data = readtable("heartdisease.xlsx");
disp(data)

% Preprocessing
disp('ismissing')
checkNa = ismissing(data);
disp(checkNa)
disp('rmissing')
cleanData = rmmissing(data);
disp(cleanData)

% Normalisasi dengan method ‘zscore’
disp('Normalisasi')
normalisasi = normalize(cleanData, 'zscore');
disp(normalisasi)


% Mencari PCA
disp('matriks data')
matriksData = table2array(normalisasi);
disp(matriksData)

disp('Y')
Y = matriksData(:,12);
disp(Y)

[coeff, score, ~,~,explained] = pca(matriksData);

% Menghitung jumlah principal component yang akan digunakan
disp('num_components')
num_components = find(cumsum(explained)/sum(explained) >= 0.70, 1);
disp(num_components)

% Memproyeksikan data ke matriks yang baru
disp('matriks pca')
matriks_pca = matriksData * coeff(:,1:num_components);
disp(matriks_pca)

% Membagi data menjadi 2 untuk training dan testing
disp('Membagi data training dan testing')
cv = cvpartition(Y,'HoldOut',0.5);
Xtrain = matriks_pca(cv.training,:);
Ytrain = Y(cv.training);
Xtest = matriks_pca(cv.test,:);
Ytest = Y(cv.test);
disp('Data X Training')
disp(Xtrain);
disp('Data Y Training')
disp(Ytrain);
disp('Data X Testing')
disp(Xtest);
disp('Data Y Testing')
disp(Ytest);

% Decission Tree
% Train classifier on training data
disp('Klasifikasi data training')
dt = fitctree(Xtrain,Ytrain);
disp(dt)

% Test classifier on testing data 
disp('klasifikasi testing data')
Ypreddt = dt.predict(Xtest);
disp(Ypreddt)

% Evaluate performance
disp('Evaluasi')
cm = confusionmat(Ytest,Ypreddt);
confusionchart(cmdt)
ig = confusionchart(cm,"Title","Decission Tree");

% Akurasi
fprintf('Akurasi = ')
accuracy = sum(Ypreddt == Ytest)/length(Ytest);
disp(accuracy)
%Precision
fprintf('Precision = ')
precision = cm(2,2)/(cm(2,2)+cm(1,2));
disp(precision)
% Recall
fprintf('Recall = ')
recall = cm(2,2)/(cm(2,2)+cm(2,1));
disp(recall)