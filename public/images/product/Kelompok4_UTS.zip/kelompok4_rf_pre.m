% Membaca data
data = readtable("heartdisease.xlsx");
disp(data)

% Preprocessing
disp('ismissing')
checkNa = ismissing(data);
disp(checkNa)
disp('rmissing')
cleanData = rmmissing(data);
disp(cleanData)

% Normalisasi dengan method ‘zscore’
disp('Normalisasi')
normalisasi = normalize(cleanData, 'zscore');
disp(normalisasi)

% Mencari PCA
disp('matriks data')
matriksData = table2array(normalisasi);
disp(matriksData)
disp('Y')
Y = matriksData(:,12);
disp(Y)
[coeff, score, ~,~,explained] = pca(matriksData);

% Menghitung jumlah principal component yang akan digunakan
disp('num_components')
num_components = find(cumsum(explained)/sum(explained) >= 0.70, 1);
disp(num_components)

% Memproyeksikan data ke matriks yang baru
disp('matriks pca')
matriks_pca = matriksData * coeff(:,1:num_components);
disp(matriks_pca)

% Membagi data menjadi 2 untuk training dan testing
disp('Membagi data training dan testing')
cv = cvpartition(Y,'HoldOut',0.5);
Xtrain = matriks_pca(cv.training,:);
Ytrain = Y(cv.training);
Xtest = matriks_pca(cv.test,:);
Ytest = Y(cv.test);
disp('Data X Training')
disp(Xtrain);
disp('Data Y Training')
disp(Ytrain);
disp('Data X Testing')
disp(Xtest);
disp('Data Y Testing')
disp(Ytest);

% Random Forest
% Train classifier on training data
disp('Klasifikasi data training')
rf = fitcensemble(Xtrain,Ytrain);
disp(rf)

% Train classifier on testing data
disp('Klasifikasi data testing')
yPredrf = rf.predict(Xtest);
disp(yPredrf)

% Evaluate performance
disp('Evaluasi')
cmrf = confusionmat(Ytest,yPredrf);
confusionchart(cmrf)
ignrf = confusionchart(cmrf,"Title","Random Forest");
% Akurasi
fprintf('Akurasi = ')
accuracyrf = sum(yPredrf == Ytest)/length(Ytest);
disp(accuracyrf)
% Precision
fprintf('Precision = ')
precisionrf = cmrf(2,2)/(cmrf(2,2)+cmrf(1,2));
disp(precisionrf)
% Recall
fprintf('Recall = ')
recallrf = cmrf(2,2)/(cmrf(2,2)+cmrf(2,1));
disp(recallrf)